import java.util.Scanner;

public class pwcracker {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String pass;
        int length;

        System.out.println("Masukkan Password lebih dari 5 karakter tanpa angka: ");
        pass = "" + scan.nextLine();
        length = pass.length();

        SequentialPatternGenerator generator = new SequentialPatternGenerator(length);

        generator.forEachRemaining(search -> {if(pass.equals(search)) {
            System.out.println("password: " + search );
        }});

    }
}
